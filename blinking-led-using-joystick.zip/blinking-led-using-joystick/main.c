#include <msp430.h> 


#define LED1    BIT7
#define LED2    BIT6
#define BUTTON1  BIT6
#define BUTTON2  BIT5

void main(void) {
    WDTCTL = WDTPW | WDTHOLD;


    P10DIR |= LED1 + LED2;
    P10OUT &= ~(LED1 + LED2);

    P1DIR &= ~BUTTON1;
    P1REN |= BUTTON1;
    P1OUT |= BUTTON1;

    P1DIR &= ~BUTTON2;
    P1REN |= BUTTON2;
    P1OUT |= BUTTON2;

    while(1) {
        if((P1IN & BUTTON1) == 0) {
            __delay_cycles(20000);

            if((P1IN & BUTTON1) == 0) {
                P10OUT ^= LED1;


                while((P1IN & BUTTON1) == 0);

                __delay_cycles(20000);

            }
        }

                if((P1IN & BUTTON2) == 0) {
                            __delay_cycles(20000);

                             if((P1IN & BUTTON2) == 0) {
                                 P10OUT ^= LED2;


                                  while((P1IN & BUTTON2) == 0);

                                   __delay_cycles(20000);
                           }
                        }

    }

}
